[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo_id=9216943&assignment_repo_type=AssignmentRepo)
# Winter Semester 2022 - Project

Be sure to show all your work for credit, you must turn in your code as well as all output files.

***Please generate a report that contains the code and output in a single readable format using Latex.***

## Getting Started
- Clone your own assignment repository into your own computer
- Determine how you will use Latex, either:
  - download Latex for your platform. Windows users can download MiKTeX or TeX Live [preferred]
  - utilize an online Latex editor. Overleaf is recommended
- Read the project description carefully, implement necessary functions, and generate your report using the Latex article class
- Handing in your homework amounts to committing and pushing changes you have made in your repository before the deadline
- For further testing, download the "standard" test images from the [Gonzalez and Woods website](http://www.imageprocessingplace.com/root_files_V3/image_databases.htm)

## Description
The final project is an open-ended research project based on material you have been exposed to in the course and through publications. A good project topic is concrete and narrowly-scoped enough to be completed with a few weeks of hard work but could potentially lead to deeper research investigations and publications. The project should be completed in group, however with a distinct contribution from each student. In the end, you will submit a report and do a final presentation at the completion of the project, and there will be a competition to which the winner will get a prize.

## Proposal
An initial project proposal must be submitted before 13.11.2022. The proposal is a very short document (half a page), which describes the high-level functionality of the project. It should specify what the project will do and any tools, libraries, or data sets that will be utilized. Be sure to include references that you have used to help form your project. The proposal will be evaluated to ensure the difficultly level is appropriate and to get recommendations of other resources that may be helpful. Please push the short proposal document within your repository under the proposal directory. **Please note, it is not allowed to use machine learning approaches in your project.**

## Presentation
Each group will have 10 minutes to give a conference presentation of their projects in class starting on 12.01.2023. The presentation will be followed by 5 min questions. The presentation should highlight the problem, solution, and demonstrate your project live (in action) and in a demo video. Please push your presentation files to presentation directory prior to class so they may be pre-loaded in case you have problems presenting on your own machine.

## Report
At the completion of the project, a report must be generated to describe the project. The project report will be written in an academic conference style. Unless you have a particular publication venue you will target for your project, you should use [IEEE's Latex conference template](https://www.ieee.org/conferences/publishing/templates.html). Please push all Latex files to the report directory. The project report should be approximately 6 pages and contain the following sections:
1. Abstract - This brief summary of the project purpose presents a general overview of the project topic and solution.
2. Introduction - The introduction should introduce readers to the project topic and clearly explain the problem, application domain, and need for the project.
3. Background - The report must highlight previous research in your topic area and clearly explain why this project is meaningful.
4. Implementation - The project implementation provides the details on how the specified problem was solved. This will include a system diagram as well as a description of each of the system components. The system component description must detail the purpose and the mathematical/computational framework.
5. Experimental Evaluation - The experimental section describes how the project program performance was evaluated. This section should provide examples that highlight the operation of your system. There should be some form of numerical performance quantification and/or comparison to literature where applicable.
6. Conclusion - The conclusion of the report should provide a summary of the project aim and results as well as highlight further research directions.
7. Contribution - It should highlight by name what was the contribution of each student in the group

## Deliverables and Deadlines
The following highlight the important dates and items to be submitted for the project. The project will be worth 20% of your overall course grade.

### Deliverable
- Electronic submission including the following in separate folders:
  - proposal,
  - code,
  - report,
  - presentation, and
  - demo video 

### Deadlines
- 13.11.2022: Project proposal
- 07.01.2023: Project deliverables (code & report)
- 12.01.2023: Project deliverables (presentation & demo video)
