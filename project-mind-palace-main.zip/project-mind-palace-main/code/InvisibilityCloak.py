import cv2
import time
import numpy as np

def realtimeCloak():
    cap = cv2.VideoCapture(0)

    # Store a single frame as background 
    _, background = cap.read()
    time.sleep(2)
    _, background = cap.read()

    #define all the kernels size  
    open_kernel = np.ones((7,7),np.uint8) #was (5,5)
    close_kernel = np.ones((7,7),np.uint8)
    dilation_kernel = np.ones((10, 10), np.uint8)

    # Function for remove noise from mask 
    def filter_mask(mask):

        close_mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, close_kernel)

        open_mask = cv2.morphologyEx(close_mask, cv2.MORPH_OPEN, open_kernel)

        dilation = cv2.dilate(open_mask, dilation_kernel, iterations= 1)

        return dilation

    while cap.isOpened():
        ret, frame = cap.read()  # Capture every frame
        # convert to hsv colorspace 
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        
        # lower bound and upper bound for Green color 
        # lower_range = (0, 50, 50)
        # upper_range = (10, 255, 255)

        
        lowerredcolor=np.array([0,120,70])
        upperredcolor=np.array([10,255,255])
        maskingupper=cv2.inRange(hsv,lowerredcolor,upperredcolor)   

        lowerredcolor=np.array([170,120,70])
        upperredcolor=np.array([180,255,255])
        maskinglower=cv2.inRange(hsv,lowerredcolor,upperredcolor)
        
        mask=maskingupper+maskinglower
        mask=cv2.morphologyEx(mask,cv2.MORPH_OPEN,np.ones((3,3), np.uint8), iterations=10)
        mask=cv2.morphologyEx(mask,cv2.MORPH_DILATE,np.ones((3,3), np.uint8), iterations=1)
        
        # find the colors within the boundaries
        #mask = cv2.inRange(hsv, lower_range, upper_range)

        # Filter mask
        #mask = filter_mask(mask)

        # Apply the mask to take only those region from the saved background 
        # where our cloak is present in the current frame
        cloak = cv2.bitwise_and(background, background, mask=mask)

        # create inverse mask 
        inverse_mask = cv2.bitwise_not(mask)  

        # Apply the inverse mask to take those region of the current frame where cloak is not present 
        current_background = cv2.bitwise_and(frame, frame, mask=inverse_mask)

        # Combine cloak region and current_background region to get final frame 
        combined = cv2.add(cloak, current_background)

        cv2.imshow("Invisibility Cloak", combined)


        if cv2.waitKey(1) == ord('q'):
            break
        
    cap.release()
    cv2.destroyAllWindows()

#------------------------------------------------------------------------------------------------------------------------

def invisibilityCloak():
    capture = cv2.VideoCapture(0)
    ret, frame = capture.read()
    capture.release()

    # Save the image to a file
    cv2.imwrite('background.jpg', frame)

    time.sleep(5)

    capture = cv2.VideoCapture(0)
    ret, frame = capture.read()
    capture.release()

    # Save the image to a file
    cv2.imwrite('image.jpg', frame)

    time.sleep(5)
    img = cv2.imread('image.jpg')
    # img = cv2.imread('cv-red.png')

    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    #Now we set the range for lower red brigtness/varients
    lowerredcolor=np.array([0,120,70])
    upperredcolor=np.array([10,255,255])

    maskingupper=cv2.inRange(hsv,lowerredcolor,upperredcolor)   
    #to fit in opencv(since its 8 bit value) inrange returns binary mask where their pixel of value where 255 falls into upperend
    #range for the upper end of red color brigtness/varients

    lowerredcolor=np.array([170,120,70])
    upperredcolor=np.array([180,255,255])

    maskinglower=cv2.inRange(hsv,lowerredcolor,upperredcolor) 

    #generate the final mask to hide red color by comining both masks for upper and lower
    redhidemask=maskingupper+maskinglower
    redhidemask=cv2.morphologyEx(redhidemask,cv2.MORPH_OPEN,np.ones((3,3), np.uint8), iterations=10)
    redhidemask=cv2.morphologyEx(redhidemask,cv2.MORPH_DILATE,np.ones((3,3), np.uint8), iterations=1)

    # cv2.imshow("MASK",redhidemask)

    background = cv2.imread('background.jpg')
    cloak = cv2.bitwise_and(background, background, mask=redhidemask)

    inverse_mask = cv2.bitwise_not(redhidemask)
    current_background = cv2.bitwise_and(img, img, mask=inverse_mask)
    combined = cv2.add(cloak, current_background)

    # cv2.imshow("Invisibility Cloak",combined)
    cv2.imwrite('final.jpg', combined)

#------------------------------------------------------------------------------------------------------------------------

def main():
    realtimeCloak()
    # invisibilityCloak()

if __name__ == "__main__":
    main()    